﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coc.Modeling.Uml
{
    public class UmlActionState : UmlElement
    {

        public UmlLane ParentLane { get; set; }
    }
}
