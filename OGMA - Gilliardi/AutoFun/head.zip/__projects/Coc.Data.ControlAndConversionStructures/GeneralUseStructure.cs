﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Coc.Data.ControlStructure;

namespace Coc.Data.ControlAndConversionStructures
{
    /*
    /// <summary>
    /// <img src="images/ControlAndConversionStructures.PNG"/>
    /// </summary>
    public static class NamespaceDoc
    {
    }*/


    public abstract class GeneralUseStructure
    {
        public StructureType type { get; set;}
    }
}
