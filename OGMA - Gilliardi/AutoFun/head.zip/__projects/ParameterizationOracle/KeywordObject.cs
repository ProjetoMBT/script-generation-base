﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParameterizationOracle
{
    public class KeywordObject
    {
        public KeywordObject()
        {

        }

        public String Name { get; set; }
    }
}
