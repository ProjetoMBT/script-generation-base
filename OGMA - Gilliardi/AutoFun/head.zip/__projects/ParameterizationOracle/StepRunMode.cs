﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParameterizationOracle
{
    public class StepRunMode
    {
        public StepRunMode()
        {

        }

        public String Name { get; set; }
    }
}
