﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParameterizationOracle
{
    public class ScriptAction
    {
        public ScriptAction()
        {

        }

        public String Name { get; set; }

        public ScriptObject RelatedObject { get; set; }
    }
}
