﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FunctionalTool.Modeling.Uml
{
    public class UmlFlow : UmlAssociation{
    }
}
