﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UmlComponentDiagramEditor
{
    public enum ConnectionPosition
    {
        Up,
        Down,
        Left,
        Right,
        Center,
    };
}
