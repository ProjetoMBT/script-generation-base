package Diagrams;

public class UmlUseCaseDiagram extends UmlDiagram
{

}
