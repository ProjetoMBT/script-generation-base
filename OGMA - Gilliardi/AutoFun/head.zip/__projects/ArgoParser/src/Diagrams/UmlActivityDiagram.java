package Diagrams;

import Objects.UmlLane;
import java.util.ArrayList;

public class UmlActivityDiagram extends UmlDiagram
{
    private ArrayList<UmlLane> Lanes = new ArrayList<>();
}
