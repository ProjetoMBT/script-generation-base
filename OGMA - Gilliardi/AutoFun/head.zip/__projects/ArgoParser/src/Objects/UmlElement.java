package Objects;

public abstract class UmlElement extends UmlBase
{

}
