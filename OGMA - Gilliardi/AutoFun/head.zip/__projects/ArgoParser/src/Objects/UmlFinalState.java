package Objects;

public class UmlFinalState extends UmlPseudoState
{

}
