package Objects;

public class UmlActionState extends UmlElement
{
    private int ParentLane;
}
