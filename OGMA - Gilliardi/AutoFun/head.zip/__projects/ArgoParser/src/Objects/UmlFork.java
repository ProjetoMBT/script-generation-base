package Objects;

public class UmlFork extends UmlPseudoState
{

}
