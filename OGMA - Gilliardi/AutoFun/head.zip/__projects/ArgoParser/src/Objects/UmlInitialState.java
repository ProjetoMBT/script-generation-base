package Objects;

public class UmlInitialState extends UmlPseudoState
{

}
