package Objects;

public class UmlDecision extends UmlPseudoState
{

}
