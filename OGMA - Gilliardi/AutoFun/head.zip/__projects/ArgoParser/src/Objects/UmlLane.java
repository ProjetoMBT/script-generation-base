package Objects;

import java.util.ArrayList;

public class UmlLane extends UmlBase
{
    private ArrayList<UmlElement> Elements;

    private int Index;

    public void AddElement(UmlElement element)
    {

    }

    public void RemoveElement(UmlElement element)
    {

    }

    public void ClearElements()
    {

    }

    public ArrayList<UmlElement> GetElements()
    {
        return null;
    }

    public void CompareTo(Object obj)
    {

    }
}
