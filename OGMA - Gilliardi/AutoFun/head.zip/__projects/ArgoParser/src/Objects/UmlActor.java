package Objects;

public class UmlActor extends UmlElement
{

}
