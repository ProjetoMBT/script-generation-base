package Objects;

public class UmlUseCase extends UmlElement
{

}
