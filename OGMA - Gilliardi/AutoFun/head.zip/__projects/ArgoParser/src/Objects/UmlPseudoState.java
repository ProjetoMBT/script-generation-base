package Objects;

public abstract class UmlPseudoState extends UmlActionState
{

}
