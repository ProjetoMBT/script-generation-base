package Objects;

public class UmlJoin extends UmlPseudoState
{

}
